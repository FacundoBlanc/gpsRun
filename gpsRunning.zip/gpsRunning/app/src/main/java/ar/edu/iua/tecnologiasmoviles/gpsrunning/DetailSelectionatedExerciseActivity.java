package ar.edu.iua.tecnologiasmoviles.gpsrunning;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class DetailSelectionatedExerciseActivity extends Fragment {

    View lv;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.fragment_detail_selectionated_exercise);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        lv = inflater.inflate(R.layout.fragment_detail_selectionated_exercise,container,false);

        return lv;

    }

    public void onViewCreated(View view, Bundle savedInstanceState){
        super.onViewCreated(view,savedInstanceState);

        //TextView textView = lv.findViewById(R.id.textView2);


    }
}
