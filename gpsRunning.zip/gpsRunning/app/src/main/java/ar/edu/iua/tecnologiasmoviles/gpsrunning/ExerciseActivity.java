package ar.edu.iua.tecnologiasmoviles.gpsrunning;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;

import ar.edu.iua.tecnologiasmoviles.gpsrunning.fragments.DetailFragment;
import ar.edu.iua.tecnologiasmoviles.gpsrunning.fragments.ListAllExercisesFragment;
import ar.edu.iua.tecnologiasmoviles.gpsrunning.fragments.MapsFragment;
import ar.edu.iua.tecnologiasmoviles.gpsrunning.model.Exercise;

//public class ExerciseActivity extends AppCompatActivity implements DetailFragment.OnFragmentInteractionListener, MapsFragment.OnFragmentInteractionListener {
public class ExerciseActivity extends Fragment implements ListAllExercisesFragment.OnFragmentInteractionListener, MapsFragment.OnFragmentInteractionListener {

    LocationCallback mLocationCallback;
    LocationRequest mLocationRequest;
    FusedLocationProviderClient mFusedLocationProviderClient;

    View vie;

    //protected void onCreate(Bundle savedInstanceState) {
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        vie = inflater.inflate(R.layout.activity_exercise, container, false);

        return vie;

    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }


}
