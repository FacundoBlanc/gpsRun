package ar.edu.iua.tecnologiasmoviles.gpsrunning.fragments;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;

import org.w3c.dom.Text;

import ar.edu.iua.tecnologiasmoviles.gpsrunning.R;



public class DetailFragment extends Fragment {

    View vg;

    private Chronometer simpleChronometer;
    private boolean running;
    private long pauseOffset;
    LocationCallback mLocationCallback;
    LocationRequest mLocationRequest;
    FusedLocationProviderClient mFusedLocationProviderClient;
    private static final int REQUEST_PERMISSIONS = 100;
    boolean boolean_permission;

    //experimento
    private static final int REQUEST_LOCATION = 1;

    private OnFragmentInteractionListener mListener;

    public DetailFragment() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        vg = inflater.inflate(R.layout.fragment_detail, container, false);
        //return inflater.inflate(R.layout.fragment_detail, container, false);
        //Chronometer simpleChronometer = (Chronometer) vg.findViewById(R.id.simpleChronometer);

        Button btnStart = vg.findViewById(R.id.btnStartExer);
        Button btnPause = vg.findViewById(R.id.btnPause);
        Button btnStop = vg.findViewById(R.id.btnStop);

        simpleChronometer = (Chronometer) vg.findViewById(R.id.simpleChronometer);
        simpleChronometer.setFormat("Tiempo : %s");
        simpleChronometer.setBase(SystemClock.elapsedRealtime());


        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startChronometer(v);
            }
        });

        btnPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseChronometer(v);
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopChronometer(v);
            }
        });


        final TextView textt = vg.findViewById(R.id.vel);

        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                if (locationResult == null) {
                    return;
                } else {
                    for (Location location : locationResult.getLocations()) {
                        textt.setText(String.valueOf(locationResult.getLastLocation()));
                    }
                }
            }
        };

        return vg;
    }

    public void startChronometer(View v) {
        if (!running) {
            simpleChronometer.setBase(SystemClock.elapsedRealtime() - pauseOffset);
            simpleChronometer.start();
            running = true;

            MapsFragment mapa = (MapsFragment)getFragmentManager().findFragmentById(R.id.fragmentMap);
            //mapa.mapaComenzar();
        }
    }

    public void pauseChronometer(View v) {
        if (running) {
            simpleChronometer.stop();
            pauseOffset = SystemClock.elapsedRealtime() - simpleChronometer.getBase();
            running = false;
        }
    }

    public void stopChronometer(View v) {
        simpleChronometer.setBase(SystemClock.elapsedRealtime());
        pauseOffset = 0;
        simpleChronometer.stop();
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    public void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setFastestInterval(10000);
        mLocationRequest.setFastestInterval(5000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }


}