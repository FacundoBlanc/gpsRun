package ar.edu.iua.tecnologiasmoviles.gpsrunning.fragments;

import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import ar.edu.iua.tecnologiasmoviles.gpsrunning.model.ExerciseSingleton;
import ar.edu.iua.tecnologiasmoviles.gpsrunning.util.ExerciseJSONParser;
import ar.edu.iua.tecnologiasmoviles.gpsrunning.R;
import ar.edu.iua.tecnologiasmoviles.gpsrunning.model.Exercise;
import ar.edu.iua.tecnologiasmoviles.gpsrunning.pruebaActivity;

public class ListAllExercisesFragment extends Fragment {

    List<Exercise> dataExercise = new ArrayList<>();
    View lv;

    ExerciseSingleton exerciseSingleton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.fragment_listallexercises);

    }


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        lv = inflater.inflate(R.layout.fragment_listallexercises,container,false);

        ListView list = (ListView) lv.findViewById(R.id.listViewActivity);

        CustomListAdapter customListAdapter = new CustomListAdapter();
        list.setAdapter(customListAdapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //ListView l = lv.findViewById(R.id.listViewActivity);
                ///l.setAdapter(null);
                //Fragment detailExerciseActivity = new DetailSelectionatedExerciseActivity();
                //FragmentManager manager = getFragmentManager();
                //manager.beginTransaction().replace(R.id.listViewActivity,detailExerciseActivity,detailExerciseActivity.getTag()).commit();

                Intent inte = new Intent(getContext(),pruebaActivity.class);
                startActivity(inte);
            }
        });

        return lv;

    }


    private class CustomListAdapter extends BaseAdapter{

        public CustomListAdapter() {
            //InputStream jsonInput = getResources().openRawResource(R.raw.exercise);

            //ExerciseJSONParser exerciseJSONParser = new ExerciseJSONParser();

            /*try{
                dataExercise = exerciseJSONParser.getJsonStream(jsonInput);
            }catch (IOException e) {
                e.printStackTrace();
            }*/

            dataExercise = ExerciseSingleton.getInstance().getData();

           /* exerciseSingleton.getInstance().loadData(getContext());
            dataExercise = exerciseSingleton.getData();*/

        }

        @Override
        public int getCount() {
            return dataExercise.size();
        }

        @Override
        public Object getItem(int position) {
            return dataExercise.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            if(view==null){
                view = getLayoutInflater().inflate(R.layout.list_cell, viewGroup,false);
            }

            TextView durationC = view.findViewById(R.id.cellDuration);
            durationC.setText(String.valueOf(dataExercise.get(i).getDuration()));

            TextView speedC = view.findViewById(R.id.cellSpeed);
            speedC.setText(String.valueOf(dataExercise.get(i).getSpeed()));

            TextView distanceC = view.findViewById(R.id.cellDistance);
            distanceC.setText(String.valueOf(dataExercise.get(i).getDistance()));

            return view;
        }
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }



}
