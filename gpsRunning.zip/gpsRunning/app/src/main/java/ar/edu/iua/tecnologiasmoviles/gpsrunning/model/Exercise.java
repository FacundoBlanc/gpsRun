package ar.edu.iua.tecnologiasmoviles.gpsrunning.model;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;

public class Exercise {

    private int id;
    private Double duration;
    private Double speed;
    private Double distance;
    private List<LatLng> listLocalization ;  //preguntar como parsear a LatLng


    public Exercise() {
    }

    public Exercise(int id, Double duration, Double speed, Double distance, List<LatLng> listLocalization) {
        this.id = id;
        this.duration = duration;
        this.speed = speed;
        this.distance = distance;
        this.listLocalization = listLocalization;
    }

    public List<LatLng> getListLocalization() {
        return listLocalization;
    }

    public void setListLocalization(List<LatLng> listLocalization) {
        this.listLocalization = listLocalization;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Double getDuration() {
        return duration;
    }

    //public String getDuration1(){
      //  return String.valueOf(duration);
    //}


    public void setDuration(Double duration) {
        this.duration = duration;
    }

    public Double getSpeed() {
        return speed;
    }

    public void setSpeed(Double speed) {
        this.speed = speed;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }
}
