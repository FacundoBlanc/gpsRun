package ar.edu.iua.tecnologiasmoviles.gpsrunning.model;

import android.content.Context;
import android.content.res.AssetFileDescriptor;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import ar.edu.iua.tecnologiasmoviles.gpsrunning.ExerciseActivity;
import ar.edu.iua.tecnologiasmoviles.gpsrunning.R;
import ar.edu.iua.tecnologiasmoviles.gpsrunning.util.ExerciseJSONParser;

public class ExerciseSingleton {
    private static ExerciseSingleton instancia = null;
    Exercise exercise;
    List<Exercise> datosExercise ;

    private Context context;

    private ExerciseSingleton(){
        if(datosExercise == null){
            datosExercise = new ArrayList<>();
        }
    }

    public static ExerciseSingleton getInstance(){
        if(instancia == null){
            synchronized (ExerciseSingleton.class){
                if(instancia == null){
                    instancia = new ExerciseSingleton();
                }
            }
        }

        return instancia;
    }


    public void loadData(Context context){
        InputStream jsonInput = context.getResources().openRawResource(R.raw.exercise);

        ExerciseJSONParser exerciseJSONParser = new ExerciseJSONParser();

        try {
            datosExercise = exerciseJSONParser.getJsonStream(jsonInput);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error de parseo");
        }

    }

    public List<Exercise> getData(){
        return datosExercise;
    }

}
