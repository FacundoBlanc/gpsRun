package ar.edu.iua.tecnologiasmoviles.gpsrunning.util;

import android.util.JsonReader;
import android.util.JsonToken;

import com.google.android.gms.maps.model.LatLng;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.InputStream;
import java.io.InputStreamReader;

import ar.edu.iua.tecnologiasmoviles.gpsrunning.model.Exercise;


public class ExerciseJSONParser {

    public List<Exercise> getJsonStream(InputStream in) throws IOException{

        JsonReader jsonReader = new JsonReader(new InputStreamReader(in));

        return getDataArray(jsonReader);

    }

    private List<Exercise> getDataArray(JsonReader reader)throws IOException{

        List <Exercise> exercise = new ArrayList<Exercise>();

        reader.beginArray();
        while (reader.hasNext()){
            exercise.add(getData(reader));
        }
        reader.endArray();
        return exercise;
    }

    private Exercise getData(JsonReader reader) throws IOException{

        Exercise exercise = new Exercise();
        reader.beginObject();
        while (reader.hasNext()){

            switch (reader.nextName()){

                case "id":
                    exercise.setId(reader.nextInt());
                    break;

                case "duration":
                    exercise.setDuration(reader.nextDouble());
                    break;

                case "distance":
                    exercise.setDistance(reader.nextDouble());
                    break;

                case "speed":
                    exercise.setSpeed(reader.nextDouble());
                    break;

                    case "localization":
                        exercise.setListLocalization(readLatLng(reader));
                        break;

                default:
                    reader.skipValue();
                    break;
            }
        }

        reader.endObject();
        return exercise;
    }

    public List<LatLng> readLatLng(JsonReader reader) throws IOException {
        List<LatLng> geoL = new ArrayList<>();

        reader.beginArray();
        while (reader.hasNext()) {
            double latitude = 0.0;
            double longitude = 0.0;
            String nextValue = "";
            reader.beginObject();

            while(reader.hasNext()){
                switch (reader.nextName()){
                    case "latitude":
                        nextValue = "latitude";
                        latitude = reader.nextDouble();
                        break;

                    case "longitude":
                        nextValue = "longitude";
                        longitude = reader.nextDouble();
                        break;

                        default:
                            reader.skipValue();
                            break;
                }

                if(nextValue.equals("longitude")){
                    LatLng latLng = new LatLng(latitude,longitude);
                    geoL.add(latLng);
                }

            }
            reader.endObject();
        }
        reader.endArray();
        return geoL;
    }

}
